// script.js

let startTime = 0;
let elapsedTime = 0;
let timerInterval;
let running = false;

// انتخاب عناصر HTML
const display = document.getElementById('display');
const startStopButton = document.getElementById('start-stop');
const resetButton = document.getElementById('reset');

// مدیریت دکمه "شروع/توقف"
startStopButton.addEventListener('click', () => {
    if (!running) {
        startStopButton.textContent = 'Stop';
        startTime = Date.now() - elapsedTime;
        timerInterval = setInterval(updateDisplay, 10);
        running = true;
    } else {
        startStopButton.textContent = 'Start';
        clearInterval(timerInterval);
        running = false;
    }
});

// مدیریت دکمه "ریست"
resetButton.addEventListener('click', () => {
    clearInterval(timerInterval);
    running = false;
    elapsedTime = 0;
    display.textContent = '00:00:00.000';
    startStopButton.textContent = 'Start';
});

// به‌روزرسانی نمایش کرنومتر
function updateDisplay() {
    elapsedTime = Date.now() - startTime;
    display.textContent = formatTime(elapsedTime);
}

// فرمت‌دهی زمان به صورت ساعت:دقیقه:ثانیه.میلی‌ثانیه
function formatTime(time) {
    const milliseconds = Math.floor(time % 1000);
    const seconds = Math.floor((time / 1000) % 60);
    const minutes = Math.floor((time / (1000 * 60)) % 60);
    const hours = Math.floor((time / (1000 * 60 * 60)) % 24);

    return (
        (hours ? String(hours).padStart(2, '0') + ':' : '') +
        String(minutes).padStart(2, '0') + ':' +
        String(seconds).padStart(2, '0') + '.' +
        String(milliseconds).padStart(3, '0')
    );
}
