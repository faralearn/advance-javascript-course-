const musics = [
    {name : "ehsan khaje amiri - Darya" , cover : "img/ehsan1.jpg" , audio : "./music/Darya.mp3"},
    {name : "ehsan khaje amiri - in hagham nist" , cover : "img/ehsan2.jpg" , audio : "./music/InHaghamNist.mp3"},
    {name : "ehsan khaje amiri - Lahze" , cover : "img/ehsan3.jpg" , audio : "./music/Lahze.mp3"}
]


let musicName = document.getElementById("music-name")
let musicCover = document.getElementById("music-cover")
let range = document.getElementById("music-time")
let preBtn = document.getElementById("pre-btn")
let playBtn = document.getElementById("play-btn")
let nextBtn = document.getElementById("next-btn")



let currentMusic = 0;

let audio = new Audio(musics[currentMusic].audio)




updateMusicInfo()
function updateMusicInfo(){
    musicName.innerHTML = musics[currentMusic].name;
    musicCover.src = musics[currentMusic].cover;
    audio.src = musics[currentMusic].audio;
}

audio.addEventListener("canplay" , ()=>{
    range.max = audio.duration
})


audio.addEventListener("timeupdate" , ()=>{
    range.value = audio.currentTime;
})


range.addEventListener("input" , ()=>{
    audio.currentTime = range.value;
})



playBtn.addEventListener("click" , ()=>{
    if(audio.paused){
        audio.play()
        playBtn.classList.replace("fa-play" , "fa-pause");
        musicCover.style.animationPlayState = "running"

    }else{
        audio.pause();
        playBtn.classList.replace("fa-pause" , "fa-play");
        musicCover.style.animationPlayState = "paused"


    }
})


nextBtn.addEventListener("click" , ()=>{
    currentMusic++;
    if(currentMusic > musics.length - 1){   
        currentMusic = 0
    }
    playBtn.classList.replace("fa-play" , "fa-pause");
    changeMusic()
})


preBtn.addEventListener("click" , ()=>{
    currentMusic--;
    if(currentMusic < 0){
        currentMusic = musics.length - 1
    }
    playBtn.classList.replace("fa-play" , "fa-pause");
    

    changeMusic()
})






function changeMusic(){
    audio.pause();
    updateMusicInfo();
    audio.play()
}