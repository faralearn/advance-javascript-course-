﻿let input = document.getElementById("password-field");
let iconEye = document.getElementById("iconEye");


iconEye.addEventListener("click" , function(){
  if(input.type === "text"){
    input.type = "password"
    iconEye.className = "fa fa-eye";
  }else{
    input.type = "text"
    iconEye.className = "fa fa-eye-slash";
  }
})