const bgColorBtns = document.querySelectorAll('[data-bg-color]');
const textColorBtns = document.querySelectorAll('[data-text-color]');

bgColorBtns.forEach(btn => {
    btn.style.backgroundColor = btn.dataset.bgColor;
    btn.addEventListener('click', function() {
        document.documentElement.style.setProperty('--bg-color', btn.dataset.bgColor);
    });
});

textColorBtns.forEach(btn => {
    btn.style.backgroundColor = btn.dataset.textColor;
    btn.addEventListener('click', function() {
        document.documentElement.style.setProperty('--text-color', btn.dataset.textColor);
    });
});