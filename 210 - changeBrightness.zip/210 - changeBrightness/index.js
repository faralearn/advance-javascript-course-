let range = document.getElementById("range")
let container = document.querySelector(".container")


// range.addEventListener("change" , (event)=>{
//     container.style.filter = "brightness(" + event.target.value + "%)"
    
// })


range.addEventListener("input" , (event)=>{
    container.style.filter = "brightness(" + event.target.value + "%)"
    
})