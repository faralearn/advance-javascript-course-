// script.js

let events = JSON.parse(localStorage.getItem('events')) || [];

// انتخاب عناصر HTML
const eventNameInput = document.getElementById('event-name');
const eventTimeInput = document.getElementById('event-time');
const addEventButton = document.getElementById('add-event-button');
const eventsList = document.getElementById('events-list');
const warning = document.getElementById("warning")

addEventButton.addEventListener('click', addEvent);

function addEvent() {
    const eventName = eventNameInput.value;
    const eventTime = new Date(eventTimeInput.value);




    if (eventName.length <= 0 || isNaN(eventTime.getTime())) {
        warning.style.display = "block"
    } else {
        warning.style.display = "none"

        const newEvent = { name: eventName, time: eventTime.getTime() };
        events.push(newEvent);
        localStorage.setItem('events', JSON.stringify(events));
        renderEvents();
        eventNameInput.value = '';
        eventTimeInput.value = '';
    }


}

function renderEvents() {
    eventsList.innerHTML = '';
    events.forEach((event, index) => {
        const eventElement = document.createElement('div');
        eventElement.className = 'event';
        const timeRemaining = calculateTimeLeft(event.time);
        eventElement.innerHTML = `
            <span>${event.name} - <span class="time-remaining">${timeRemaining}</span></span>
            <button class="delete-button" onclick="deleteEvent(${index})">Delete</button>
        `;
        eventsList.appendChild(eventElement);
    });
}

function calculateTimeLeft(eventTime) {
    const now = new Date();
    const diff = eventTime - now;

    if (diff <= 0) {
        return 'Event has started!';
    }

    const seconds = Math.floor((diff / 1000) % 60);
    const minutes = Math.floor((diff / 1000 / 60) % 60);
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function deleteEvent(index) {
    events.splice(index, 1);
    localStorage.setItem('events', JSON.stringify(events));
    renderEvents();
}

function updateCountdowns() {
    events.forEach((event, index) => {
        const eventElement = eventsList.children[index];
        const timeRemainingSpan = eventElement.querySelector('.time-remaining');
        const timeRemaining = calculateTimeLeft(event.time);
        timeRemainingSpan.textContent = timeRemaining;

        if (timeRemaining === 'Event has started!') {
            eventElement.classList.add('started');
        } else {
            eventElement.classList.remove('started');
        }
    });
}

// به‌روزرسانی شمارش معکوس هر ثانیه
setInterval(updateCountdowns, 1000);

// بارگذاری اولیه
renderEvents();
