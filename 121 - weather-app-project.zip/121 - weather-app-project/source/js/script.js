let citiesData = {
  tehran : {city : "tehran" , temp: 12 , weather : "Sunny" , humidity : 23 , windSpeed: 32 , windDirection: "to north" , logo: "image/sunny.png" , wallpaper: "image/tehran.jpg"},
  shiraz : {city : "shiraz" , temp: 25 , weather : "Storm" , humidity : 20 , windSpeed: 22 , windDirection: "to north" , logo: "image/storm.png" , wallpaper: "image/shiraz.jpg"},
  esfahan : {city : "esfahan" , temp: 15 , weather : "Sunny" , humidity : 23 , windSpeed: 32 , windDirection: "to north" , logo: "image/sunny.png" , wallpaper: "image/esfahan.jpg"},
  khorramabad : {city : "khorramabad" , temp: 8 , weather : "snow" , humidity : 23 , windSpeed: 32 , windDirection: "to north" , logo: "image/snow.png" , wallpaper: "image/khorramabad.jpg"},
  yazd : {city : "yazd" , temp: 30 , weather : "rainy" , humidity : 23 , windSpeed: 32 , windDirection: "to north" , logo: "image/rainy.png" , wallpaper: "image/yazd.jpg"},
}


let searchBar = document.querySelector(".search-bar");
let searchBtn = document.getElementById("search");


searchBtn.addEventListener("click" , function(){
  let searchBarValue = searchBar.value;
  let mainCityDatas = citiesData[searchBarValue];



  if(mainCityDatas){
    document.querySelector(".city").innerHTML = "weather in " + mainCityDatas.city;
    document.querySelector(".temp").innerHTML = mainCityDatas.temp + "C";
    document.querySelector(".description").innerHTML = mainCityDatas.weather;
    document.querySelector(".icon").setAttribute("src" , mainCityDatas.logo);
    document.querySelector(".humidity").innerHTML = "humidity is " + mainCityDatas.humidity;
    document.querySelector(".wind").innerHTML = "wind speed is " + mainCityDatas.windSpeed + "km/h";
    document.querySelector(".windDirection").innerHTML = "wind direction is " + mainCityDatas.windDirection;
    document.body.style.backgroundImage = "url(" + mainCityDatas.wallpaper + ")";
    document.getElementById("msg").style.display = "none";




  }else{
    document.getElementById("enterCity").innerHTML = "enter your city correctly";
    document.getElementById("enterCity").style.color = "red";
    document.getElementById("enterCity").style.fontSize = "25px";
    document.getElementById("enterCity").style.fontWeight = "bold";
    document.getElementById("enterCity").style.textAlign = "center";
    document.getElementById("msg").style.display = "none";
  }




})

