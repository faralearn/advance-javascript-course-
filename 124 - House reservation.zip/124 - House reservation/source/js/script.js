﻿

let countrySelectBox = document.querySelector(".countrySelect");
let citySelect = document.querySelector(".citySelect");


let contriesData = {
  lorestan : ["khorramabad" , "aligodarz" , "boroujerd" , "azna" , "aleshtar"],
  tehran : ["tehran" , "damavand" , "varamin" , "pakdasht"],
  esfahan : ["esfahan" , "najaf abad" , "kashan" , "shareza"]
}

countrySelectBox.addEventListener("change" , function(){
  if(countrySelectBox.value == "Please Select ..."){
    citySelect.innerHTML = "";
    citySelect.innerHTML = "<option >Select City ...</option>";
  }else{
    let mainCountryName = countrySelectBox.value;
    let mainCountryCity = contriesData[mainCountryName];

    citySelect.innerHTML = "";

    mainCountryCity.forEach(function(city){
      citySelect.innerHTML += " <option> " + city + "</option>"
    })
  }
})


