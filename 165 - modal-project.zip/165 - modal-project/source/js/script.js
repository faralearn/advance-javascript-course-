const button = document.querySelector("button");
const modalParent = document.querySelector(".modal-parent1");
const X = document.querySelector(".X");
const sectionElem = document.querySelector("section");
const notSave = document.getElementById("notSave")
const save = document.getElementById("save")
const saved = document.getElementById("saved");
const secondModal = document.getElementById("second-modal");
const x2 = document.getElementById("x2");


function showModal(){
    modalParent.style.display = "block";
    sectionElem.style.filter = "blur(10px)";
    button.blur();
}


function hideModal(){
    modalParent.style.display = "none";
    sectionElem.style.filter = "blur(0px)"

}



function hideModalWithEsc(event){
    if(event.keyCode === 27){
        modalParent.style.display = "none";
        sectionElem.style.filter = "blur(0px)" 
    }
}



function showSecondModal(){
    modalParent.style.display = "none";
    secondModal.style.display = "block";
    sectionElem.style.filter = "blur(10px)" 

}


function hideSecondModal(){
    secondModal.style.display = "none";
    sectionElem.style.filter = "blur(0px)" 

}


function hideSecondModalWithEsc(event){
    if(event.keyCode === 27){
        secondModal.style.display = "none";
        sectionElem.style.filter = "blur(0px)" 
    }
}



button.addEventListener("click" , showModal);
X.addEventListener("click" , hideModal)
document.body.addEventListener("keyup" , hideModalWithEsc);
notSave.addEventListener("click" , hideModal);
save.addEventListener("click" , showSecondModal);
saved.addEventListener("click" , hideSecondModal);
x2.addEventListener("click" , hideSecondModal);
document.body.addEventListener("keyup" , hideSecondModalWithEsc)